package com.tngtech.jira.plugins.gadget.chart;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Paint;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.TickUnitSource;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.GroupedStackedBarRenderer;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.urls.StandardCategoryURLGenerator;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.category.CategoryDataset;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.StandardGradientPaintTransformer;

import com.atlassian.jira.charts.jfreechart.ChartGenerator;
import com.atlassian.jira.charts.jfreechart.ChartHelper;
import com.atlassian.jira.charts.jfreechart.util.ChartUtil;
import com.atlassian.jira.web.bean.I18nBean;
import com.tngtech.jira.plugins.utils.JiraUtils;

public class BarChartGenerator implements ChartGenerator {

	private static final double MAXIMUM_BAR_WIDTH = 0.04;
	private final CategoryDataset dataset;
	private final JiraUtils jiraUtils;

	public BarChartGenerator(CategoryDataset dataset, JiraUtils jiraUtils) {
		this.dataset = dataset;
		this.jiraUtils = jiraUtils;
	}

	@Override
	public ChartHelper generateChart() {
		return generateChart("", true);
	}

	public ChartHelper generateChart(String xAxisFieldName, boolean legend) {
		boolean tooltips = true;
		boolean urls = true;
	//	System.out.println("GenerateChart Rest Resource xAxisFieldName : "+xAxisFieldName);
		JFreeChart chart = ChartFactory.createStackedBarChart("", xAxisFieldName, jiraUtils
				.getTranslatedText("gadget.barchart.chart.countissues"), dataset, PlotOrientation.HORIZONTAL, legend,
				tooltips, urls);
		
		
/*		GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();
        KeyToGroupMap map = new KeyToGroupMap();
        map.getGroups();
       
        renderer.setSeriesToGroupMap(map); 
        
        renderer.setItemMargin(0.0);*/
		
		
		//chart.setBorderVisible(true);
		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		
		formatAxes(plot);
		setChartDefaults(chart, plot, jiraUtils.geti18nBean());
		return new ChartHelper(chart);
	}
	
	public class CustomRenderer extends BarRenderer 
	{ 
	 /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	private Paint[] colors;

	 public CustomRenderer() 
	 { 
	    this.colors = new Paint[] {Color.red, Color.blue, Color.green, 
	      Color.yellow, Color.orange, Color.cyan, 
	      Color.magenta, Color.blue}; 
	 }

	 public Paint getItemPaint(final int row, final int column) 
	 { 
	    // returns color for each column 
	    return (this.colors[row % this.colors.length]); 
	 } 
	public  StackedBarRenderer renderer = new StackedBarRenderer();
	}

	private void formatAxes(CategoryPlot plot) {
		NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
		System.out.println("FormatAxex YAXIS :  "+yAxis);
		TickUnitSource units = NumberAxis.createIntegerTickUnits();
		System.out.println(" TickUnitSource UNITS :  "+units);
		yAxis.setStandardTickUnits(units);
		yAxis.setAutoRange(true);
		yAxis.setAutoRangeIncludesZero(true);
		CategoryAxis xAxis = plot.getDomainAxis();
		System.out.println("FormatAxex XAXIS :  "+xAxis);

		xAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
	}

	@SuppressWarnings("deprecation")
	private void setChartDefaults(JFreeChart chart, CategoryPlot plot, I18nBean bean) {
		ChartUtil.setDefaults(chart, bean);
		//StackedBarRenderer renderer = new StackedBarRenderer();
		//CategoryItemRenderer renderer = new CustomRenderer(); 
		// set the color (r,g,b) or (r,g,b,a)
		//Color color = new Color(79, 129, 189);
		//renderer.setSeriesPaint(0, color);
		//plot.setRenderer(renderer);
		/*StackedBarRenderer render = new StackedBarRenderer();
		render.setMaximumBarWidth(MAXIMUM_BAR_WIDTH);
		plot.setRenderer(render);*/
		
		GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();
        KeyToGroupMap map = new KeyToGroupMap("G1");
        map.mapKeyToGroup("Red", "G1");
        map.mapKeyToGroup("Yellow", "G2");
        map.mapKeyToGroup("Green", "G3");
        renderer.setSeriesToGroupMap(map); 
        renderer.setItemMargin(0.0);
        Paint p1 = new GradientPaint(
            0.0f, 0.0f, new Color(0x22, 0x22, 0xFF), 0.0f, 0.0f, new Color(0x88, 0x88, 0xFF)
        );
        renderer.setSeriesPaint(0, p1);
        /*renderer.setSeriesPaint(4, p1);
        renderer.setSeriesPaint(8, p1);*/
        
        Paint p2 = new GradientPaint(
                0.0f, 0.0f, new Color(0x22, 0xFF, 0x22), 0.0f, 0.0f, new Color(0x88, 0xFF, 0x88)
            );
        renderer.getSeriesItemURLGenerator(2);
            renderer.setSeriesPaint(1, p2); 
           /* renderer.setSeriesPaint(5, p2); 
            renderer.setSeriesPaint(9, p2); */
            
            Paint p3 = new GradientPaint(
                0.0f, 0.0f, new Color(0xFF, 0x22, 0x22), 0.0f, 0.0f, new Color(0xFF, 0x88, 0x88)
            );
            renderer.setSeriesPaint(2, p3);
          /*  renderer.setSeriesPaint(6, p3);
            renderer.setSeriesPaint(10, p3);*/
                
            Paint p4 = new GradientPaint(
                0.0f, 0.0f, new Color(0xFF, 0xFF, 0x22), 0.0f, 0.0f, new Color(0xFF, 0xFF, 0x88)
            );
            renderer.setSeriesPaint(3, p4);
           /* renderer.setSeriesPaint(7, p4);
            renderer.setSeriesPaint(11, p4);*/
            renderer.setGradientPaintTransformer(
                 new StandardGradientPaintTransformer(GradientPaintTransformType.HORIZONTAL)
            );
        
            renderer.setItemURLGenerator(new StandardCategoryURLGenerator("www.google.com","series","section")); 
            renderer.setToolTipGenerator(new StandardCategoryToolTipGenerator());            
            
            
            plot.setRenderer(renderer);
        
	}

}